package com.banking.services;

public class User {
	
	private int id;
	private String name;
	private double amount;
	private String accounttype;
	
	
	
	public User(int id, String name, double amount, String accounttype) {
		
		this.id = id;
		this.name = name;
		this.amount = amount;
		this.accounttype = accounttype;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public String getAccounttype() {
		return accounttype;
	}
	public void setAccounttype(String accounttype) {
		this.accounttype = accounttype;
	}
	

}
