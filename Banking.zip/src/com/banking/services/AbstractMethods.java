package com.banking.services;

public interface AbstractMethods {
	
	
	public void credit(int amount,User user);
	public void debit(int amount,User user);
	public void dispaly();

}
