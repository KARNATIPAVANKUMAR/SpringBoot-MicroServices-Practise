package com.banking.services;

public class CurrentAccount implements AbstractMethods {

	@Override
	public void credit(int amount, User user) {
		// TODO Auto-generated method stub
		user.setAmount(user.getAmount()+amount);
		
	}

	@Override
	public void debit(int amount, User user) {
		// TODO Auto-generated method stub
		if(amount<=user.getAmount())
		{
			user.setAmount(user.getAmount()-amount);
		}
		else {
		System.out.println("No sufficient balance");
		}
	}

	@Override
	public void dispaly() {
		System.out.println("Your balance is:");
		
	}

	
}
